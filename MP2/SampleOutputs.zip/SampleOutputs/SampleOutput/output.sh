python mp2.py --map Test1 --config=test_config.txt --granularity=5 --trajectory=2 --method=bfs --save-image=SampleOutput/test1g5.png --save-maze=SampleOutput/test1g5.txt

python mp2.py --map Test1 --config=test_config.txt --granularity=2 --trajectory=2 --method=bfs --save-image=SampleOutput/test1g2.png --save-maze=SampleOutput/test1g2.txt

python mp2.py --map Test2 --config=test_config.txt --granularity=5 --trajectory=2 --method=bfs --save-image=SampleOutput/test2g5.png --save-maze=SampleOutput/test2g5.txt

python mp2.py --map BasicMap --config=test_config.txt --granularity=5 --trajectory=2 --method=bfs --save-image=SampleOutput/test2g5.png --save-maze=SampleOutput/basicmapg5.txt


python mp2.py --map Map1 --config=config.txt --granularity=5 --trajectory=2 --method=bfs --save-image=SampleOutput/map1g5.png --save-maze=SampleOutput/map1g5.txt

python mp2.py --map Map2 --config=config.txt --granularity=5 --trajectory=2 --method=bfs --save-image=SampleOutput/map2g5.png --save-maze=SampleOutput/map2g5.txt

python mp2.py --map Map3 --config=config.txt --granularity=5 --trajectory=2 --method=bfs --save-image=SampleOutput/map3g5.png --save-maze=SampleOutput/map3g5.txt

python mp2.py --map Map4 --config=config.txt --granularity=5 --trajectory=2 --method=bfs --save-image=SampleOutput/map4g5.png --save-maze=SampleOutput/map4g5.txt
